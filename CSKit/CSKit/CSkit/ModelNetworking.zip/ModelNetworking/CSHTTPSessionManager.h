//
//  CSHTTPSessionManager.h
//  CSCategory
//
//  Created by mac on 2017/6/24.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSCacheManager.h"
#import "CSHTTPClientManager.h"
#import <Foundation/Foundation.h>
#import "NSFileManager+pathMethod.h"

typedef void (^CSRequestConfig)(CSHTTPClientManager *request);
typedef void (^CSRequestSuccess)(id responseObj,CSAPiType type);
typedef void (^CSRequestFailed)(NSError *error);
typedef void (^CSProgressBlock)(NSProgress * progress);
@protocol CSURLSessionDelegate;


@interface CSHTTPSessionManager : NSObject<NSURLSessionDelegate>

@property (nonatomic,   weak) id<CSURLSessionDelegate>delegate;
@property (nonatomic,   copy) NSURLSession *urlSession;
@property (nonatomic, strong) CSHTTPClientManager *request;
@property (nonatomic, strong) void (^requestSuccess)(id responseObj,CSAPiType type);
@property (nonatomic, strong) void (^requestFailed)(NSError *error);



/** 创建并返回一个 CSHTTPSessionManager */
+ (instancetype)manager;

/** 单例对象 */
+ (CSHTTPSessionManager *)sharedInstance;



/**
 设置请求头
 请在请求前使用该方法,如果在请求后使用,则不会起作用

 @param value The value set as default for the specified header
 @param field The HTTP header to set a default value for
 */
- (void)setValue:(NSString *)value forHTTPHeaderField:(NSString *)field;

/**
 返回请求操作中设置的HTTP头的值

 @param field The HTTP header to retrieve the default value for
 */
- (NSString *)valueForHTTPHeaderField:(NSString *)field;


/**
 使被管理会话无效,可选择取消挂起的任务

 @param cancelPendingTasks 是否取消挂起的任务
 */
- (void)requestToCancel:(BOOL)cancelPendingTasks;

/**
 *  离线下载 请求方法
 *
 *  @param downloadArray 请求列队
 *  @param delegate      代理  传实现协议的对象
 *  @param type          用于直接区分不同的request对象 离线下载 为 ZBRequestTypeOffline
 */
- (void)offlineDownload:(NSMutableArray *)downloadArray target:(id<CSURLSessionDelegate>)delegate apiType:(CSAPiType)type;

/**
 GET请求, POST无效

 @param config 请求配置代码块
 @param success 请求成功代码块
 @param failed 请求失败代码块
 */
- (void)requestWithConfig:(CSRequestConfig)config  success:(CSRequestSuccess)success failed:(CSRequestFailed)failed;

/**
 GET请求, 代理方式(需自行实现代理)

 @param urlString  get 路径
 @param delegate 传实现协议的对象
 */
- (void)getRequestWithURL:(NSString *)urlString target:(id<CSURLSessionDelegate>)delegate;

/**
 GET请求, 代理方式(需自行实现代理)
 
 @param urlString  get 路径
 @param delegate 传实现协议的对象
 @param type 区分request对象类型
 */
- (void )getRequestWithURL:(NSString *)urlString target:(id<CSURLSessionDelegate>)delegate apiType:(CSAPiType)type;

/**
 GET请求

 @param urlString get 路径
 @param type 区分request对象类型
 @param success 请求成功代码块
 @param failed 请求失败代码块
 */
- (void )getRequestWithURL:(NSString *)urlString apiType:(CSAPiType)type success:(CSRequestSuccess)success failed:(CSRequestFailed)failed;

/**
 POST请求

 @param urlString 请求路径
 @param parameters 请求参数
 @param delegate 传实现协议的对象
 */
- (void)postRequestWithURL:(NSString *)urlString parameters:(NSDictionary*)parameters target:(id<CSURLSessionDelegate>)delegate;

/**
 GET请求类方法

 @param urlString 请求路径
 @param delegate 传实现协议的对象
 @return 请求对象
 */
+ (CSHTTPSessionManager *)getRequestWithURL:(NSString *)urlString target:(id<CSURLSessionDelegate>)delegate;

/**
 GET请求类方法

 @param urlString 请求路径
 @param delegate 传实现协议的对象
 @param type 区分request对象类型
 @return 请求对象
 */
+ (CSHTTPSessionManager *)getRequestWithURL:(NSString *)urlString target:(id<CSURLSessionDelegate>)delegate apiType:(CSAPiType)type;

/**
 POST请求

 @param urlString 请求路径
 @param parameters 请求参数
 @param delegate 传实现协议的对象
 @return 请求对象
 */
+ (CSHTTPSessionManager *)postRequestWithURL:(NSString *)urlString parameters:(NSDictionary*)parameters target:(id<CSURLSessionDelegate>)delegate;



@end



@protocol CSURLSessionDelegate <NSObject>
@required
/**
 数据请求成功代理

 @param request CSHTTPClientManager
 */
- (void)urlRequestFinished:(CSHTTPClientManager *)request;
@optional
/**
 数据请求失败代理

 @param request CSHTTPClientManager
 */
- (void)urlRequestFailed:(CSHTTPClientManager *)request;

@end
