//
//  CSNetworkManager.m
//  CSCategory
//
//  Created by mac on 2017/6/24.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "CSNetworkManager.h"
#import <AFNetworking.h>
#import "NSFileManager+pathMethod.h"
#import <AFNetworkActivityIndicatorManager.h>

static const NSInteger timeOut = 60*60;
@interface CSNetworkManager ()

@property (nonatomic, strong) AFHTTPSessionManager *AFmanager;
@property AFNetworkReachabilityStatus netStatus;

@end

@implementation CSNetworkManager

+ (CSNetworkManager *)sharedInstance {
    static CSNetworkManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[CSNetworkManager alloc] init];
    });
    return sharedInstance;
}

- (id)init{
    self = [super init];
    if (self) {
        
        self.request.responseObj=[[NSMutableData alloc]init];
        
        self.request.timeoutInterval=15;
        
    }
    return self;
}
- (void)dealloc {
    if (self.AFmanager) {
        [CSNetworkManager requestToCancel:YES];
    }
}

+ (CSNetworkManager *)requestWithConfig:(requestConfig)config  success:(requestSuccess)success failed:(requestFailed)failed{
    return [CSNetworkManager requestWithConfig:config progress:nil success:success failedBlock:failed];
}

+ (CSNetworkManager *)requestWithConfig:(requestConfig)config progress:(progressBlock)progressBlock  success:(requestSuccess)success failedBlock:(requestFailed)failed{
    
    CSNetworkManager *manager=[[CSNetworkManager alloc]init];
    
    config ? config(manager.request) : nil;
    
    if (manager.request.methodType == CSMethodTypePOST) {
        [manager POST:manager.request.urlString parameters:manager.request.parameters progress:progressBlock success:success failed:failed];
    }else{
        if (manager.request.apiType== CSAPiTypeOffline) {
            [manager offlineDownload:manager.request.urlArray apiType:manager.request.apiType success:success failed:failed];
        }else{
            [manager GET:manager.request.urlString parameters:manager.request.parameters apiType:manager.request.apiType progress:progressBlock success:success failed:failed];
        }
    }
    return manager;
}

- (void)offlineDownload:(NSMutableArray *)downloadArray apiType:(CSAPiType)type success:(requestSuccess)success failed:(requestFailed)failed{
    if (downloadArray.count==0)return;
    [downloadArray enumerateObjectsUsingBlock:^(NSString *urlString, NSUInteger idx, BOOL *stop) {
        [self GET:urlString parameters:nil apiType:type progress:nil success:success failed:failed ];
    }];
}

- (void)GET:(NSString *)urlString success:(requestSuccess)success failed:(requestFailed)failed{
    [self GET:urlString parameters:nil success:success failed:failed];
}

- (void)GET:(NSString *)urlString parameters:(id)parameters success:(requestSuccess)success failed:(requestFailed)failed{
    [self GET:urlString parameters:parameters progress:nil success:success failed:failed];
}

- (void)GET:(NSString *)urlString parameters:(id)parameters progress:(progressBlock)progressBlock success:(requestSuccess)success failed:(requestFailed)failed{
    [self GET:urlString parameters:parameters apiType:CSAPiTypeDefault progress:progressBlock success:success failed:failed];
}

- (void)GET:(NSString *)urlString parameters:(id)parameters apiType:(CSAPiType)type  progress:(progressBlock)progressBlock success:(requestSuccess)success failed:(requestFailed)failed{
    
    NSString *path =[[CSCacheManager sharedInstance] pathWithFileName:urlString];
    
    if ([[CSCacheManager sharedInstance] isExistsAtPath:path]&&[NSFileManager isTimeOutWithPath:path timeOut:timeOut]==NO&&type!=CSAPiTypeRefresh&&type!=CSAPiTypeOffline){
        CSHTTPClientLog(@"AF cache");
        NSData *data = [NSData dataWithContentsOfFile:path];
        
        [self.request.responseObj appendData:data];
        
        success ? success(self.request.responseObj ,type) : nil;
    }else{
        [self GET:urlString parameters:parameters path:path progress:progressBlock success:success failed:failed];
    }
}

- (void)GET:(NSString *)urlString parameters:(id)parameters path:(NSString *)path progress:(progressBlock)progressBlock success:(requestSuccess)success failed:(requestFailed)failed{
    if(!urlString)return;
    CSHTTPClientLog(@"AF GET");
    [self.AFmanager GET:urlString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
        progressBlock ? progressBlock(downloadProgress) : nil;
        
    }success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
        
        [[CSCacheManager sharedInstance] setContent:responseObject writeToFile:path];
        
        success ? success(responseObject,self.request.apiType) : nil;
        
    }failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull   error) {
        failed ? failed(error) : nil;
    }];
    
    
}
- (void)POST:(NSString *)urlString parameters:(id)parameters success:(requestSuccess)success failed:(requestFailed)failed{
    [self POST:urlString parameters:parameters progress:nil success:success failed:failed];
}

- (void)POST:(NSString *)urlString parameters:(id)parameters progress:(progressBlock)progressBlock success:(requestSuccess)success failed:(requestFailed)failed{
    if(!urlString)return;
    CSHTTPClientLog(@"AF POST");
    [self.AFmanager POST:urlString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
        progressBlock ? progressBlock(uploadProgress) : nil;
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        success ? success(responseObject,self.request.apiType) : nil;
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failed ? failed(error) : nil;
    }];
    
}

+ (void)requestToCancel:(BOOL)cancelPendingTasks{
    [[CSNetworkManager sharedInstance].AFmanager invalidateSessionCancelingTasks:cancelPendingTasks];
}

- (NSInteger)startNetWorkMonitoring{
    self.netStatus=[AFNetworkReachabilityManager sharedManager].networkReachabilityStatus;
    // 设置网络状态改变后的处理
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        // 当网络状态改变了, 就会调用这个block
        self.netStatus=status;
        switch (self.netStatus)
        {
            case AFNetworkReachabilityStatusUnknown: // 未知网络
                
                break;
            case AFNetworkReachabilityStatusNotReachable: // 没有网络(断网)
                
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN: // 手机自带网络
                
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi: // WIFI
                
                break;
        }
    }];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    return self.netStatus;
}

- (AFHTTPSessionManager*)AFmanager{
    if (!_AFmanager) {
        _AFmanager=[AFHTTPSessionManager manager];
        //和urlsession类 公用一个chche容器 返回类型全部是二进制
        _AFmanager.requestSerializer  = [AFHTTPRequestSerializer serializer];// 设置请求格式
        _AFmanager.responseSerializer = [AFHTTPResponseSerializer serializer]; // 设置返回格式
        
        [[self.request mutableHTTPRequestHeaders] enumerateKeysAndObjectsUsingBlock:^(id field, id value, BOOL * __unused stop) {
            CSHTTPClientLog(@"%@-%@",field,value);
            [_AFmanager.requestSerializer setValue:value forHTTPHeaderField:field];
        }];
        [_AFmanager.requestSerializer setTimeoutInterval:self.request.timeoutInterval];
        _AFmanager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html",@"application/json",@"text/json", @"text/plain",@"text/javascript", nil];
        //如果你用的是自签名的证书
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
        securityPolicy.allowInvalidCertificates = YES;
        securityPolicy.validatesDomainName = NO;
        _AFmanager.securityPolicy = securityPolicy;
    }
    
    return _AFmanager;
}

- (CSHTTPClientManager*)request{
    if (!_request) {
        _request = [[CSHTTPClientManager alloc]init];
    }
    
    return _request;
}

@end
