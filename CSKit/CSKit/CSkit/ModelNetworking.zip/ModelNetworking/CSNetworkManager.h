//
//  CSNetworkManager.h
//  CSCategory
//
//  Created by mac on 2017/6/24.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CSHTTPSessionManager.h"

typedef void (^requestConfig)(CSHTTPClientManager *request);
typedef void (^requestSuccess)(id responseObj,CSAPiType type);
typedef void (^requestFailed)(NSError *error);
typedef void (^progressBlock)(NSProgress * progress);

@interface CSNetworkManager : NSObject

@property (nonatomic,strong) CSHTTPClientManager *request;
/**
 *  用于标识不同类型的方法
 */
@property (nonatomic,assign) CSMethodType methodType;

/**
 返回单例对象
 
 @return  ZBNetworkManager 对象
 */
+ (CSNetworkManager *)sharedInstance;
/**
 *  请求方法 get/post
 *
 *  @param config           请求配置  Block
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
+ (CSNetworkManager *)requestWithConfig:(requestConfig)config  success:(requestSuccess)success failed:(requestFailed)failed;
/**
 *  请求方法 get/post
 *
 *  @param config           请求配置  Block
 *  @param progress         请求进度  Block
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
+ (CSNetworkManager *)requestWithConfig:(requestConfig)config progress:(progressBlock)progress  success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  请求方法 get/post
 *
 *  @param urlString        请求的协议地址
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)GET:(NSString *)urlString success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  get请求
 *
 *  @param urlString        请求的协议地址
 *  @param parameters       请求所用的参数
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)GET:(NSString *)urlString parameters:(id)parameters success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  get请求
 *
 *  @param urlString        请求的协议地址
 *  @param parameters       请求所用的参数
 *  @param progress         请求进度  Block
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)GET:(NSString *)urlString parameters:(id)parameters progress:(progressBlock)progress success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  get请求
 *
 *  @param urlString        请求的协议地址
 *  @param parameters       请求所用的参数
 *  @param type             请求类型
 *  @param progress         请求进度  Block
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)GET:(NSString *)urlString parameters:(id)parameters apiType:(CSAPiType)type progress:(progressBlock)progress success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  post 请求
 *
 *  @param urlString        请求的协议地址
 *  @param parameters       请求所用的参数
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)POST:(NSString *)urlString parameters:(id)parameters success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  post 请求
 *
 *  @param urlString        请求的协议地址
 *  @param parameters       请求所用的参数
 *  @param progress         请求进度  Block
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)POST:(NSString *)urlString parameters:(id)parameters progress:(progressBlock)progress success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  离线下载 请求方法
 *
 *  @param downloadArray    请求列队
 *  @param type             用于直接区分不同的request对象 离线下载 为 ZBRequestTypeOffline
 *  @param success          请求成功的 Block
 *  @param failed           请求失败的 Block
 */
- (void)offlineDownload:(NSMutableArray *)downloadArray apiType:(CSAPiType)type success:(requestSuccess)success failed:(requestFailed)failed;

/**
 *  请求会话管理,取消请求任务
 *  Invalidates the managed session, optionally canceling pending tasks.
 *
 *  @param cancelPendingTask Whether or not to cancel pending tasks.
 */
+ (void)requestToCancel:(BOOL)cancelPendingTask;

/**
 *  网络状态监测
 */
+ (NSInteger)startNetWorkMonitoring;

@end
