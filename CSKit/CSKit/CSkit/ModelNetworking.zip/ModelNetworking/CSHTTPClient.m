//
//  CSHTTPClient.m
//  CSCategory
//
//  Created by mac on 2017/6/16.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "CSHTTPClient.h"
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#pragma GCC diagnostic ignored "-Wdeprecated-implementations"

typedef void (^RequestResultBlock)(NSData *data, CSModelError *error);

#pragma mark - constants
NSString* const kHTTPMethodGET = @"GET";
NSString* const kHTTPMethodPOST = @"POST";

NSString* const kContentTypeAutomatic    = @"jsonmodel/automatic";
NSString* const kContentTypeJSON         = @"application/json";
NSString* const kContentTypeWWWEncoded   = @"application/x-www-form-urlencoded";

#pragma mark - static variables

/**
 * 默认为HTTP请求
 */
static NSStringEncoding defaultTextEncoding = NSUTF8StringEncoding;
static NSURLRequestCachePolicy defaultCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;

static int defaultTimeoutInSeconds = 60;

/**
 * Custom HTTP headers to send over with *each* request
 */
static NSMutableDictionary* requestHeaders = nil;

/**
 * 默认请求内容类型
 */
static NSString* requestContentType = nil;

#pragma mark - implementation
@implementation CSHTTPClient

#pragma mark - initialization
+(void)initialize
{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        requestHeaders = [NSMutableDictionary dictionary];
        requestContentType = kContentTypeAutomatic;
    });
}

#pragma mark - configuration methods
+(NSMutableDictionary*)requestHeaders
{
    return requestHeaders;
}

+(void)setDefaultTextEncoding:(NSStringEncoding)encoding
{
    defaultTextEncoding = encoding;
}

+(void)setCachingPolicy:(NSURLRequestCachePolicy)policy
{
    /**
     
     对特定的 URL 请求使用网络协议中实现的缓存逻辑.这是默认的策略
     NSURLRequestUseProtocolCachePolicy = 0,
     
     数据需要从原始地址加载.不使用现有缓存
     NSURLRequestReloadIgnoringLocalCacheData = 1,
     
     不仅忽略本地缓存,同时也忽略代理服务器或其他中间介质目前已有的、协议允许的缓存(未实现)
     NSURLRequestReloadIgnoringLocalAndRemoteCacheData = 4, // Unimplemented
     
     不使用任何缓存
     NSURLRequestReloadIgnoringCacheData = NSURLRequestReloadIgnoringLocalCacheData,
     
     无论缓存是否过期,先使用本地缓存数据.如果缓存中没有请求所对应的数据,那么从原始地址加载数据.
     NSURLRequestReturnCacheDataElseLoad = 2,
     
     无论缓存是否过期,先使用本地缓存数据.如果缓存中没有请求所对应的数据,那么放弃从原始地址加载数据,请求视为失败(即:'离线'模式).
     NSURLRequestReturnCacheDataDontLoad = 3,
     
     从原始地址确认缓存数据的合法性后,缓存数据就可以使用,否则从原始地址加载(未实现)
     NSURLRequestReloadRevalidatingCacheData = 5, // Unimplemented
     */
    
    defaultCachePolicy = policy;
}

+(void)setTimeoutInSeconds:(int)seconds
{
    defaultTimeoutInSeconds = seconds;
}

+(void)setRequestContentType:(NSString*)contentTypeString
{
    requestContentType = contentTypeString;
}

#pragma mark - helper methods
+(NSString*)contentTypeForRequestString:(NSString*)requestString
{
    //从默认字符串编码中获取字符集名称
    NSString* contentType = requestContentType;
    
    if (requestString.length>0 && [contentType isEqualToString:kContentTypeAutomatic]) {
        //检查最后得到的JSON数组或字典
        NSString* firstAndLastChar = [NSString stringWithFormat:@"%@%@",
                                      [requestString substringToIndex:1],
                                      [requestString substringFromIndex: requestString.length -1]
                                      ];
        
        if ([firstAndLastChar isEqualToString:@"{}"] || [firstAndLastChar isEqualToString:@"[]"]) {
            //猜测一个JSON请求
            contentType = kContentTypeJSON;
        } else {
            //后退到www格式编码参数
            contentType = kContentTypeWWWEncoded;
        }
    }
    
    //类型设置,只需添加字符集
    NSString *charset = (NSString *)CFStringConvertEncodingToIANACharSetName(CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    return [NSString stringWithFormat:@"%@; charset=%@", contentType, charset];
}

+(NSString*)urlEncode:(id<NSObject>)value
{
    //确保 param 是一个字符串
    if ([value isKindOfClass:[NSNumber class]]) {
        value = [(NSNumber*)value stringValue];
    }
    
    NSAssert([value isKindOfClass:[NSString class]], @"请求参数只能是 NSString 和 NSNumber 类型. '%@' 类型是 %@.", value, [value class]);
    
    NSString *str = (NSString *)value;
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_7_0 || __MAC_OS_X_VERSION_MIN_REQUIRED >= __MAC_10_9
    return [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
#else
    return (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(
                                                                                 NULL,
                                                                                 (__bridge CFStringRef)str,
                                                                                 NULL,
                                                                                 (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                 kCFStringEncodingUTF8));
#endif
}

#pragma mark - 网络请求方法
+(void)requestDataFromURL:(NSURL*)url method:(NSString*)method requestBody:(NSData*)bodyData headers:(NSDictionary*)headers handler:(RequestResultBlock)handler
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: url
                                                                cachePolicy: defaultCachePolicy
                                                            timeoutInterval: defaultTimeoutInSeconds];
    [request setHTTPMethod:method];
    
    if ([requestContentType isEqualToString:kContentTypeAutomatic]) {
        //自动内容类型
        if (bodyData) {
            NSString *bodyString = [[NSString alloc] initWithData:bodyData encoding:NSUTF8StringEncoding];
            [request setValue: [self contentTypeForRequestString: bodyString] forHTTPHeaderField:@"Content-type"];
        }
    } else {
        //用户设置内容类型
        [request setValue: requestContentType forHTTPHeaderField:@"Content-type"];
    }
    
    //添加定义的所有自定义标头
    for (NSString* key in [requestHeaders allKeys]) {
        [request setValue:requestHeaders[key] forHTTPHeaderField:key];
    }
    
    //添加自定义标题
    for (NSString* key in [headers allKeys]) {
        [request setValue:headers[key] forHTTPHeaderField:key];
    }
    
    if (bodyData) {
        [request setHTTPBody: bodyData];
        [request setValue:[NSString stringWithFormat:@"%lu", (unsigned long)bodyData.length] forHTTPHeaderField:@"Content-Length"];
    }
    
    void (^completionHandler)(NSData *, NSURLResponse *, NSError *) = ^(NSData *data, NSURLResponse *origResponse, NSError *origError) {
        NSHTTPURLResponse *response = (NSHTTPURLResponse *)origResponse;
        CSModelError *error = nil;
        
        //将NSError转换为JSONModelError
        if (origError) {
            error = [CSModelError errorWithDomain:origError.domain code:origError.code userInfo:origError.userInfo];
        }
        
        //HTTP错误代码401的特殊情况
        if (error.code == NSURLErrorUserCancelledAuthentication) {
            response = [[NSHTTPURLResponse alloc] initWithURL:url statusCode:401 HTTPVersion:@"HTTP/1.1" headerFields:@{}];
        }
        
        //如果不是成功状态将error设置为JSONModelError实例
        if (!error && (response.statusCode >= 300 || response.statusCode < 200)) {
            error = [CSModelError errorBadResponse];
        }
        
        //如果有错误,请将响应分配给JSONModel实例
        if (error) {
            error.httpResponse = [response copy];
        }
        
        //无反应,返回 nil
        if (!data.length) {
            data = nil;
        }
        
        handler(data, error);
    };
    
    //发起请求
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_7_0 || __MAC_OS_X_VERSION_MIN_REQUIRED >= __MAC_10_10
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
#else
    NSOperationQueue *queue = [NSOperationQueue new];
    
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        completionHandler(data, response, error);
    }];
#endif
}

+(void)requestDataFromURL:(NSURL*)url method:(NSString*)method params:(NSDictionary*)params headers:(NSDictionary*)headers handler:(RequestResultBlock)handler
{
    //创建请求体
    NSMutableString* paramsString = nil;
    
    if (params) {
        //构建一个简单的url编码的参数字符串
        paramsString = [NSMutableString stringWithString:@""];
        for (NSString* key in [[params allKeys] sortedArrayUsingSelector:@selector(compare:)]) {
            [paramsString appendFormat:@"%@=%@&", key, [self urlEncode:params[key]] ];
        }
        if ([paramsString hasSuffix:@"&"]) {
            paramsString = [[NSMutableString alloc] initWithString: [paramsString substringToIndex: paramsString.length-1]];
        }
    }
    
    //设置请求参数
    if ([method isEqualToString:kHTTPMethodGET] && params) {
        
        //向查询字符串添加GET参数
        url = [NSURL URLWithString:[NSString stringWithFormat: @"%@%@%@",
                                    [url absoluteString],
                                    [url query] ? @"&" : @"?",
                                    paramsString
                                    ]];
    }
    
    //调用synq请求方法
    [self requestDataFromURL: url
                      method: method
                 requestBody: [method isEqualToString:kHTTPMethodPOST]?[paramsString dataUsingEncoding:NSUTF8StringEncoding]:nil
                     headers: headers
                     handler:handler];
}

#pragma mark - Async network request
+(void)JSONFromURLWithString:(NSString*)urlString method:(NSString*)method params:(NSDictionary*)params orBodyString:(NSString*)bodyString completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString
                         method:method
                         params:params
                   orBodyString:bodyString
                        headers:nil
                     completion:completeBlock];
}

+(void)JSONFromURLWithString:(NSString *)urlString method:(NSString *)method params:(NSDictionary *)params orBodyString:(NSString *)bodyString headers:(NSDictionary *)headers completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString
                         method:method
                         params:params
                     orBodyData:[bodyString dataUsingEncoding:NSUTF8StringEncoding]
                        headers:headers
                     completion:completeBlock];
}

+(void)JSONFromURLWithString:(NSString*)urlString method:(NSString*)method params:(NSDictionary *)params orBodyData:(NSData*)bodyData headers:(NSDictionary*)headers completion:(JSONObjectBlock)completeBlock
{
    RequestResultBlock handler = ^(NSData *responseData, CSModelError *error) {
        id jsonObject = nil;
        
        //step 3: 如果目前没有回应，返回基本错误
        if (!responseData && !error) {
            //检查错误的响应,但没有网络错误
            error = [CSModelError errorBadResponse];
            
        }
        
        //step 4: 如果有这个回应,没有错误,转换成对象
        if (error==nil) {
            // Note: 有可能具有空响应数据(204无内容)的有效响应.
            // 所以只有在有一些响应数据时才创建JSON对象.
            if(responseData.length > 0)
            {
                //转换成一个对象
                jsonObject = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&error];
            }
        }
        //step 4.5: 覆盖边缘情况,其中有意义的内容沿错误HTTP状态代码返回
        else if (error && responseData && jsonObject==nil) {
            //尝试获取JSON对象,同时保留原始的错误对象
            jsonObject = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:nil];
            //保持responseData以防万一它包含错误信息
            error.responseData = responseData;
        }
        
        //step 5: 调用完整的块
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completeBlock) {
                completeBlock(jsonObject, error);
            }
        });
    };
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    if (bodyData) {
        [self requestDataFromURL:url method:method requestBody:bodyData headers:headers handler:handler];
    } else {
        [self requestDataFromURL:url method:method params:params headers:headers handler:handler];
    }
}

#pragma mark - request aliases
+(void)getJSONFromURLWithString:(NSString*)urlString completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString method:kHTTPMethodGET
                         params:nil
                   orBodyString:nil completion:^(id json, CSModelError* e) {
                       if (completeBlock) completeBlock(json, e);
                   }];
}

+(void)getJSONFromURLWithString:(NSString*)urlString params:(NSDictionary*)params completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString method:kHTTPMethodGET
                         params:params
                   orBodyString:nil completion:^(id json, CSModelError* e) {
                       if (completeBlock) completeBlock(json, e);
                   }];
}

+(void)postJSONFromURLWithString:(NSString*)urlString params:(NSDictionary*)params completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString method:kHTTPMethodPOST
                         params:params
                   orBodyString:nil completion:^(id json, CSModelError* e) {
                       if (completeBlock) completeBlock(json, e);
                   }];
    
}

+(void)postJSONFromURLWithString:(NSString*)urlString bodyString:(NSString*)bodyString completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString method:kHTTPMethodPOST
                         params:nil
                   orBodyString:bodyString completion:^(id json, CSModelError* e) {
                       if (completeBlock) completeBlock(json, e);
                   }];
}

+(void)postJSONFromURLWithString:(NSString*)urlString bodyData:(NSData*)bodyData completion:(JSONObjectBlock)completeBlock
{
    [self JSONFromURLWithString:urlString method:kHTTPMethodPOST
                         params:nil
                   orBodyString:[[NSString alloc] initWithData:bodyData encoding:defaultTextEncoding]
                     completion:^(id json, CSModelError* e) {
                         if (completeBlock) completeBlock(json, e);
                     }];
}

@end
