//
//  NSFileManager+pathMethod.h
//  CSCategory
//
//  Created by mac on 2017/6/24.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (pathMethod)


/**
 判断指定路径下的文件，是否超出规定时间的方法

 @param path 文件路径
 @param time 毫秒
 @return 是否超时
 */
+ (BOOL)isTimeOutWithPath:(NSString *)path timeOut:(NSTimeInterval)time;

@end
