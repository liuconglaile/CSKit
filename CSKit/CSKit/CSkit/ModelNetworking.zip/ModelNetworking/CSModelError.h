//
//  CSModelError.h
//  CSCategory
//
//  Created by mac on 2017/6/16.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

/////////////////////////////////////////////////////////////////////////////////////////////

/**
 错误枚举

 - kCSModelErrorInvalidData: 无效数据
 - kCSModelErrorBadResponse: 网络响应不良
 - kCSModelErrorBadJSON: 格式错误的JSON
 - kCSModelErrorModelIsInvalid:  模型无效
 - kCSModelErrorNilInput: 无输入
 */
typedef NS_ENUM(int, kCSModelErrorTypes)
{
    kCSModelErrorInvalidData = 1,
    kCSModelErrorBadResponse = 2,
    kCSModelErrorBadJSON = 3,
    kCSModelErrorModelIsInvalid = 4,
    kCSModelErrorNilInput = 5
};
/////////////////////////////////////////////////////////////////////////////////////////////

/** 用于JSONModelError实例的域名 */
extern NSString *const kCSModelErrorDomain;

/**
 如果模型JSON输入错过所需的密钥,请检查您返回的JSONModelError实例的userInfo字典 - 在kJSONModelMissingKeys键下,您将找到缺少键的名称列表.
 */
extern NSString *const kCSModelMissingKeys;

/**
 如果JSON输入与模型的预期类型不同,请检查您返回的JSONModelError实例的userInfo字典 - 在kJSONModelTypeMismatch键下,您将找到不匹配类型的描述.
 */
extern NSString *const kCSModelTypeMismatch;

/**
 如果在嵌套模型中发生错误,请检查您返回的JSONModelError实例的userInfo字典 
 - 在kJSONModelKeyPath键下,您将找到发生错误的键路径.
 */
extern NSString *const kCSModelKeyPath;

/////////////////////////////////////////////////////////////////////////////////////////////
/** 自定义NSError子类,用于创建常见的JSONModel错误的快捷方式 */
/////////////////////////////////////////////////////////////////////////////////////////////
@interface CSModelError : NSError

@property (strong, nonatomic) NSHTTPURLResponse *httpResponse;
@property (strong, nonatomic) NSData *responseData;

+ (id)errorInvalidDataWithMessage:(NSString *)message;
+ (id)errorInvalidDataWithMissingKeys:(NSSet *)keys;
+ (id)errorInvalidDataWithTypeMismatch:(NSString *)mismatchDescription;
+ (id)errorBadResponse;
+ (id)errorBadJSON;
+ (id)errorModelIsInvalid;
+ (id)errorInputIsNil;
- (instancetype)errorByPrependingKeyPathComponent:(NSString *)component;
/////////////////////////////////////////////////////////////////////////////////////////////

@end


