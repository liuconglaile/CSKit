//
//  CSModelError.m
//  CSCategory
//
//  Created by mac on 2017/6/16.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "CSModelError.h"

NSString* const kCSModelErrorDomain = @"JSONModelErrorDomain";
NSString* const kCSModelMissingKeys = @"kJSONModelMissingKeys";
NSString* const kCSModelTypeMismatch = @"kJSONModelTypeMismatch";
NSString* const kCSModelKeyPath = @"kJSONModelKeyPath";

@implementation CSModelError

/**
 使用代码kJSONModelErrorInvalidData = 1 创建JSONModelError实例
 */
+(id)errorInvalidDataWithMessage:(NSString*)message
{
    message = [NSString stringWithFormat:@"Invalid JSON data: %@", message];
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorInvalidData
                                  userInfo:@{NSLocalizedDescriptionKey:message}];
}

/**
 使用代码kJSONModelErrorInvalidData = 1创建JSONModelError实例
 
 @param keys 一组必需的字段名称,但在输入中找不到
 @return 自定义的 Error
 */
+(id)errorInvalidDataWithMissingKeys:(NSSet *)keys
{
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorInvalidData
                                  userInfo:@{NSLocalizedDescriptionKey:@"无效的JSON数据.输入中缺少必需的JSON键.检查错误用户信息.",kCSModelMissingKeys:[keys allObjects]}];
}

/**
 使用代码kJSONModelErrorInvalidData = 1创建JSONModelError实例
 
 @param mismatchDescription 描述遇到的类型不匹配
 */
+(id)errorInvalidDataWithTypeMismatch:(NSString*)mismatchDescription
{
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorInvalidData
                                  userInfo:@{NSLocalizedDescriptionKey:@"无效的JSON数据.JSON类型与预期类型不匹配.检查错误用户信息.",kCSModelTypeMismatch:mismatchDescription}];
}

/**
 使用代码kJSONModelErrorBadResponse = 2创建JSONModelError实例
 */
+(id)errorBadResponse
{
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorBadResponse
                                  userInfo:@{NSLocalizedDescriptionKey:@"网络响应不良,可能是JSON网址无法访问."}];
}

/**
 使用代码kJSONModelErrorBadJSON = 3创建JSONModelError实例
 */
+(id)errorBadJSON
{
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorBadJSON
                                  userInfo:@{NSLocalizedDescriptionKey:@"格式错误的JSON.检查JSONModel数据输入."}];
}

/**
 使用代码kJSONModelErrorModelIsInvalid = 4创建JSONModelError实例
 */
+(id)errorModelIsInvalid
{
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorModelIsInvalid
                                  userInfo:@{NSLocalizedDescriptionKey:@"Model does not validate. 输入数据的自定义验证失败."}];
}

/**
 使用代码kJSONModelErrorNilInput = 5创建JSONModelError实例
 */
+(id)errorInputIsNil
{
    return [CSModelError errorWithDomain:kCSModelErrorDomain
                                      code:kCSModelErrorNilInput
                                  userInfo:@{NSLocalizedDescriptionKey:@"用nil输入对象初始化模型."}];
}

/**
 创建一个新的JSONModelError与相同的值加上有关错误的键路径的信息.
 新的错误对象中的属性与来自接收者的属性相同,只是新的密钥kJSONModelKeyPath被添加到userInfo字典中.
 该键包含组件字符串参数.
 如果密钥已经存在,那么新的错误对象的前一个组件字符串将被添加到现有值中.
 
 @param component 部件
 */
- (instancetype)errorByPrependingKeyPathComponent:(NSString*)component
{
    // 创建用户信息的可变副本，以便我们可以添加它并对其进行更新
    NSMutableDictionary* userInfo = [self.userInfo mutableCopy];
    
    // 创建或更新密钥路径
    NSString* existingPath = userInfo[kCSModelKeyPath];
    NSString* separator = [existingPath hasPrefix:@"["] ? @"" : @".";
    NSString* updatedPath = (existingPath == nil) ? component : [component stringByAppendingFormat:@"%@%@", separator, existingPath];
    userInfo[kCSModelKeyPath] = updatedPath;
    
    // 创建新的错误
    return [CSModelError errorWithDomain:self.domain
                                      code:self.code
                                  userInfo:[NSDictionary dictionaryWithDictionary:userInfo]];
}


@end
